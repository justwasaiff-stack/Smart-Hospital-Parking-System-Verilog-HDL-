//--------------------------------------------------------------------------------------------------
//
// Title       : Hospital_Parking_System_Block
// Design      : design7
// Author      : Unknown
// Company     : Unknown
//
//-------------------------------------------------------------------------------------------------
//
// File        : c:\My_Designs\Hospital_Parking _System\design7\compile\Hospital_Parking_System_Block.v
// Generated   : Mon Apr 27 12:26:23 2026
// From        : c:\My_Designs\Hospital_Parking _System\design7\src\Hospital_Parking_System_Block.bde
// By          : Bde2Verilog ver. 2.01
//
//-------------------------------------------------------------------------------------------------
//
// Description : 
//
//-------------------------------------------------------------------------------------------------

`ifdef _VCP
`else
`define library(a,b)
`endif


// ---------- Design Unit Header ---------- //
`timescale 1ps / 1ps

module Hospital_Parking_System_Block (Ambulance_Sensor,Clk,Exit_Patient,Exit_Staff,Pin_Valid,Reset,Vehicle_Sensor,Ambulance_Pass,Gate_Open,Patient_Full,
Patient_Vacant,Staff_Full,Staff_Vacant,Patient_count,Stuff_count) ;

// ------------ Port declarations --------- //
input Ambulance_Sensor;
wire Ambulance_Sensor;
input Clk;
wire Clk;
input Exit_Patient;
wire Exit_Patient;
input Exit_Staff;
wire Exit_Staff;
input Pin_Valid;
wire Pin_Valid;
input Reset;
wire Reset;
input Vehicle_Sensor;
wire Vehicle_Sensor;
output Ambulance_Pass;
wire Ambulance_Pass;
output Gate_Open;
wire Gate_Open;
output Patient_Full;
wire Patient_Full;
output Patient_Vacant;
wire Patient_Vacant;
output Staff_Full;
wire Staff_Full;
output Staff_Vacant;
wire Staff_Vacant;
output [3:0] Patient_count;
wire [3:0] Patient_count;
output [3:0] Stuff_count;
wire [3:0] Stuff_count;

// -------- Component instantiations -------//

Hospital_Parking_System U1
(
	.ambulance_pass(Ambulance_Pass),
	.ambulance_sensor(Ambulance_Sensor),
	.clk(Clk),
	.exit_patient(Exit_Patient),
	.exit_staff(Exit_Staff),
	.gate_open(Gate_Open),
	.patient_count(Patient_count),
	.patient_full(Patient_Full),
	.patient_vacant(Patient_Vacant),
	.pin_valid(Pin_Valid),
	.reset(Reset),
	.staff_count(Stuff_count),
	.staff_full(Staff_Full),
	.staff_vacant(Staff_Vacant),
	.vehicle_sensor(Vehicle_Sensor)
);



endmodule 
