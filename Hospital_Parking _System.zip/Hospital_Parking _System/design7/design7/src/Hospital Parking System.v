//--------------------------------------------------------------------------------------------------
//
// Title       : \\Hospital_Parking_System
// Design      : design4
// Author      : Admin
// Company     : pnu
//
//-------------------------------------------------------------------------------------------------
//
// File        : Hospital Parking System.v
// Generated   : Wed Apr 15 19:16:09 2026
// From        : interface description file
// By          : Itf2Vhdl ver. 1.20
//
//-------------------------------------------------------------------------------------------------
//
// Description : 
//
//-------------------------------------------------------------------------------------------------
`timescale 1 ns / 1 ps

//{{ Section below this comment is automatically maintained
//   and may be overwritten
//{module {\\Hospital_Parking_System}}
module Hospital_Parking_System (
    clk,
    reset,
    vehicle_sensor,
    ambulance_sensor,
    pin_valid,
    exit_staff,
    exit_patient,
    gate_open,
    ambulance_pass,
    staff_full,
    patient_full,
    staff_vacant,
    patient_vacant,
    staff_count,
    patient_count
);

input clk, reset;
input vehicle_sensor, ambulance_sensor, pin_valid;
input exit_staff, exit_patient;

output reg gate_open;
output reg ambulance_pass;
output reg staff_full, patient_full;
output reg staff_vacant, patient_vacant;
output reg [3:0] staff_count, patient_count;

reg [2:0] state, next_state;

parameter STAFF_MAX = 4'd8;
parameter PATIENT_MAX = 4'd8;

// States
parameter RESET_STATE = 3'b000,
          IDLE = 3'b001,
          AMBULANCE_IN = 3'b010,
          STAFF_IN = 3'b011,
          PATIENT_IN = 3'b100;


// State Register

always @(posedge clk or posedge reset)
begin
    if (reset)
        state <= RESET_STATE;
    else
        state <= next_state;
end


// next state

always @(state, vehicle_sensor, ambulance_sensor, pin_valid)
begin
    case (state)
        RESET_STATE:
            next_state = IDLE;

        IDLE:
        begin
            if (vehicle_sensor == 1'b1)
            begin
                if (ambulance_sensor == 1'b1)
                    next_state = AMBULANCE_IN;
                else if (pin_valid == 1'b1)
                    next_state = STAFF_IN;
                else
                    next_state = PATIENT_IN;
            end
            else
                next_state = IDLE;
        end

        AMBULANCE_IN:
            next_state = IDLE;

        STAFF_IN:
            next_state = IDLE;

        PATIENT_IN:
            next_state = IDLE;

        default:
            next_state = IDLE;
    endcase
end


// 

always @(posedge clk or posedge reset)
begin
    if (reset)
    begin
        staff_count <= 4'b0000;
        patient_count <= 4'b0000;
    end
    else
    begin
        if (exit_staff == 1'b1 && staff_count > 0)
            staff_count <= staff_count - 1'b1;

        if (exit_patient == 1'b1 && patient_count > 0)
            patient_count <= patient_count - 1'b1;

        if (state == STAFF_IN)
        begin
            if (staff_count < STAFF_MAX)
                staff_count <= staff_count + 1'b1;
        end

        if (state == PATIENT_IN)
        begin
            if (patient_count < PATIENT_MAX)
                patient_count <= patient_count + 1'b1;
        end
    end
end


// output 

always @(state, staff_count, patient_count)
begin
    gate_open = 1'b0;
    ambulance_pass = 1'b0;

    staff_full = 1'b0;
    patient_full = 1'b0;

    staff_vacant = 1'b0;
    patient_vacant = 1'b0;

    if (staff_count < STAFF_MAX)
        staff_vacant = 1'b1;
    else
        staff_full = 1'b1;

    if (patient_count < PATIENT_MAX)
        patient_vacant = 1'b1;
    else
        patient_full = 1'b1;

    case (state)
        RESET_STATE:
        begin
            gate_open = 1'b0;
            ambulance_pass = 1'b0;
        end

        IDLE:
        begin
            gate_open = 1'b0;
            ambulance_pass = 1'b0;
        end

        AMBULANCE_IN:
        begin
            gate_open = 1'b1;
            ambulance_pass = 1'b1;
        end

        STAFF_IN:
        begin
            if (staff_count < STAFF_MAX)
                gate_open = 1'b1;
            else
                gate_open = 1'b0;
        end

        PATIENT_IN:
        begin
            if (patient_count < PATIENT_MAX)
                gate_open = 1'b1;
            else
                gate_open = 1'b0;
        end

        default:
        begin
            gate_open = 1'b0;
            ambulance_pass = 1'b0;
        end
    endcase
end

endmodule