//--------------------------------------------------------------------------------------------------
//
// Title       : Hospital_Parking_System_tb
// Design      : design4
// Author      : lay27an@outlook.com
// Company     : HP Inc.
//
//-------------------------------------------------------------------------------------------------
//
// File        : Hospital_Parking_System_tb.v
// Generated   : Thu Apr 16 17:54:29 2026
// From        : interface description file
// By          : Itf2Vhdl ver. 1.20
//
//-------------------------------------------------------------------------------------------------
//
// Description : 
//
//-------------------------------------------------------------------------------------------------
`timescale 1 ns / 1 ps	 

module Hospital_Parking_System_tb;  

  reg clk;
  reg reset;	
  reg vehicle_sensor;
  reg ambulance_sensor; 
  reg pin_valid;  
  reg exit_staff; 
  reg exit_patient; 

  wire gate_open; 
  wire ambulance_pass;  
  wire staff_full, patient_full; 
  wire staff_vacant, patient_vacant;   
  wire [3:0] staff_count, patient_count;  
 
Hospital_Parking_System Parking_System (  
.clk(clk),
.reset(reset),
.vehicle_sensor(vehicle_sensor),
.ambulance_sensor(ambulance_sensor), 
.pin_valid(pin_valid),
.exit_staff(exit_staff),
.exit_patient(exit_patient),
.gate_open(gate_open),  
.ambulance_pass(ambulance_pass), 
.staff_full(staff_full),
.patient_full(patient_full),
.staff_vacant(staff_vacant),
.patient_vacant(patient_vacant),
.staff_count(staff_count), 
.patient_count(patient_count)
); 

// Clock generation 
always #5 clk = ~clk;  
 
// Initialization 
initial begin 
  clk = 0;  
  reset = 1; 	  
  vehicle_sensor = 0; 
  ambulance_sensor = 0; 
  pin_valid = 0; 
  exit_staff = 0;
  exit_patient = 0;
  #10 reset = 0;
  
  // Scenario 1: Ambulance entry
  #10 vehicle_sensor = 1; ambulance_sensor = 1;
  #10 vehicle_sensor = 0; ambulance_sensor = 0;

  // Scenario 2: Staff entry
  #20 vehicle_sensor = 1; pin_valid = 1;
  #10 vehicle_sensor = 0; pin_valid = 0;

  // Scenario 3: Patient entry 
  #20 vehicle_sensor = 1; pin_valid = 0; 
  #10 vehicle_sensor = 0;
  
  // Scenario 4: Staff exit  
  #20 exit_staff = 1; 
  #10 exit_staff = 0;

  // Scenario 5: Patient exit 
  #20 exit_patient = 1;
  #10 exit_patient = 0;
  
  // Scenario 6: Fill staff parking 
  repeat (7) begin   
  #10 vehicle_sensor = 1; pin_valid = 1;   
  #10 vehicle_sensor = 0; pin_valid = 0; 
  end
  
  // Scenario 7: Staff Parking Becomes Full
  #20 vehicle_sensor = 1; pin_valid = 1; 
  #10 vehicle_sensor = 0; pin_valid = 0;
  
  // Scenario 8: Fill patient parking 
  repeat (7) begin   
  #10 vehicle_sensor = 1; pin_valid = 0;  
  #10 vehicle_sensor = 0; 
  end
 
  // Scenario 9: Patient Parking Becomes Full 
  #20 vehicle_sensor = 1; pin_valid = 0;  
  #10 vehicle_sensor = 0;

  // Scenario 10: Ambulance override when full
  #20 vehicle_sensor = 1; ambulance_sensor = 1; 
  #10 vehicle_sensor = 0; ambulance_sensor = 0;    

  // Scenario 11: Staff tries to enter when staff parking is full  
  // Input: vehicle detected + valid staff pin  
  // Expected output: gate stays closed, staff_count stays 8 
  #20 vehicle_sensor = 1; pin_valid = 1; 
  #10 vehicle_sensor = 0; pin_valid = 0; 

  // Scenario 12: Patient tries to enter when patient parking is full 
  // Input: vehicle detected + no valid pin 
  // Expected output: gate stays closed, patient_count stays 8
 
  #20 vehicle_sensor = 1; pin_valid = 0;
  #10 vehicle_sensor = 0;

  // Scenario 13: Staff exit from full parking
  // Input: staff exit signal 
  //  Expected output: : staff_count decreases to 7, staff parking is no longer full 
  #20 exit_staff = 1;
  #10 exit_staff = 0;

  // Scenario 14: Staff enters after one space becomes available 
  // Input: vehicle detected + valid staff pin  
  //  Expected output: : gate opens, staff_count increases to 8 again 
  #20 vehicle_sensor = 1; pin_valid = 1; 
  #10 vehicle_sensor = 0; pin_valid = 0;
  
#50 $stop;

end 
endmodule